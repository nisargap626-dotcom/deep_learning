# Deep Learning Lab (VTU 2022 Scheme, 7th Sem, CSE-AIML)

**Name:** Nisarga P
**USN:** 1AM23CI099

## Programs

| # | Program | File | Dataset |
|---|---------|------|---------|
| 1 | Word embeddings (Word2Vec) | `01_word_embeddings.py` | Sample corpus |
| 2 | Deep neural network classification | `02_deep_neural_network.py` | Iris |
| 3 | CNN image classification | `03_cnn_image_classification.py` | MNIST |
| 4 | Autoencoder for image compression | `04_autoencoder.py` | MNIST |
| 5 | Text document classification | `05_text_classification.py` | IMDB |
| 6 | Time series forecasting (LSTM) | `06_time_series_forecasting.py` | Synthetic sine wave |
| 7 | Transfer learning (MobileNetV2) | `07_transfer_learning.py` | CIFAR-10 |
| 8 | Review sentiment classification | `08_sentiment_analysis.py` | Sample reviews |

## Run

```bash
pip install -r requirements.txt
python 02_deep_neural_network.py
```
